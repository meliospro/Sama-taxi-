import React, { useState } from 'react';
import { Driver, LocationPoint } from '../../types';
import { Navigation, Plus, Minus, Compass, Bike } from 'lucide-react';

interface DakarMapProps {
  pickup?: LocationPoint | null;
  destination?: LocationPoint | null;
  drivers?: Driver[];
  selectedDriver?: Driver | null;
  routeProgress?: number; // 0 to 100
  showTraffic?: boolean;
  onMapClick?: (coords: { lat: number; lng: number; name: string }) => void;
  interactive?: boolean;
  heightClass?: string;
  zoomLevel?: number;
}

export const DakarMap: React.FC<DakarMapProps> = ({
  pickup,
  destination,
  drivers = [],
  selectedDriver,
  routeProgress = 0,
  onMapClick,
  interactive = true,
  heightClass = 'h-full min-h-[300px]',
}) => {
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  // Map coordinate conversion to SVG viewport (Dakar Peninsula: roughly Lat 14.65 to 14.78, Lng -17.53 to -17.40)
  const minLat = 14.64;
  const maxLat = 14.79;
  const minLng = -17.54;
  const maxLng = -17.38;

  const toSvgX = (lng: number) => {
    return ((lng - minLng) / (maxLng - minLng)) * 800;
  };

  const toSvgY = (lat: number) => {
    // Latitude is inverted in SVG Y coordinates
    return ((maxLat - lat) / (maxLat - minLat)) * 600;
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!interactive) return;
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !interactive) return;
    setPan({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleSvgClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!onMapClick) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = (e.clientX - rect.left - pan.x) / zoom;
    const clickY = (e.clientY - rect.top - pan.y) / zoom;

    // Convert SVG back to lat/lng
    const lng = minLng + (clickX / 800) * (maxLng - minLng);
    const lat = maxLat - (clickY / 600) * (maxLat - minLat);

    onMapClick({
      lat,
      lng,
      name: `Point sélectionné (${lat.toFixed(4)}, ${lng.toFixed(4)})`,
    });
  };

  const resetView = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  // Coordinates for pickup & destination
  const pickupPos = pickup ? { x: toSvgX(pickup.lng), y: toSvgY(pickup.lat) } : { x: 380, y: 320 };
  const destPos = destination ? { x: toSvgX(destination.lng), y: toSvgY(destination.lat) } : null;

  // Mid point curve calculation
  const getCurvePath = (p1: { x: number; y: number }, p2: { x: number; y: number }) => {
    const midX = (p1.x + p2.x) / 2 + (p2.y - p1.y) * 0.15;
    const midY = (p1.y + p2.y) / 2 - (p2.x - p1.x) * 0.15;
    return `M ${p1.x} ${p1.y} Q ${midX} ${midY} ${p2.x} ${p2.y}`;
  };

  // Car position along route if in progress
  const getCarOnRoute = () => {
    if (!destPos) return null;
    const ratio = Math.min(Math.max(routeProgress / 100, 0), 1);
    const currX = pickupPos.x + (destPos.x - pickupPos.x) * ratio;
    const currY = pickupPos.y + (destPos.y - pickupPos.y) * ratio;
    return { x: currX, y: currY };
  };

  const carPos = getCarOnRoute();

  return (
    <div
      className={`relative w-full ${heightClass} overflow-hidden bg-[#e5ecf4] select-none cursor-grab active:cursor-grabbing`}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      {/* SVG Vector Map of Dakar */}
      <svg
        className="w-full h-full transition-transform duration-75"
        viewBox="0 0 800 600"
        preserveAspectRatio="xMidYMid slice"
        onClick={handleSvgClick}
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
          transformOrigin: 'center center',
        }}
      >
        <defs>
          <linearGradient id="oceanGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#cfdfef" />
            <stop offset="100%" stopColor="#bdd4eb" />
          </linearGradient>
          <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="2" stdDeviation="3" floodOpacity="0.25" />
          </filter>
        </defs>

        {/* Ocean Background */}
        <rect width="800" height="600" fill="url(#oceanGrad)" />

        {/* Dakar Peninsula Landmass */}
        <path
          d="M 120 180 
             C 140 140, 220 100, 320 110
             C 420 120, 520 160, 620 200
             C 700 240, 780 290, 800 320
             L 800 600
             L 580 600
             C 520 540, 480 500, 420 460
             C 380 430, 340 400, 300 380
             C 240 360, 180 320, 130 270
             C 90 230, 100 200, 120 180 Z"
          fill="#f4f4ec"
          stroke="#d2d9de"
          strokeWidth="3"
        />

        {/* Dakar City districts & green zones */}
        <path
          d="M 280 200 C 330 180, 380 220, 350 260 C 320 290, 270 270, 260 230 Z"
          fill="#e1eee0"
          opacity="0.8"
        />
        <path
          d="M 450 280 C 500 260, 560 300, 520 350 C 470 380, 430 330, 450 280 Z"
          fill="#e1eee0"
          opacity="0.8"
        />

        {/* Coastlines & beaches details (Almadies, Yoff, Corniche) */}
        <path
          d="M 115 185 Q 160 210 210 260 T 320 380"
          stroke="#ffe599"
          strokeWidth="4"
          fill="none"
          strokeLinecap="round"
        />

        {/* Major Roads & Highways (VDN, Corniche, Autoroute A1) */}
        {/* VDN */}
        <path
          d="M 150 210 Q 250 220 380 280 T 520 390"
          stroke="#ffffff"
          strokeWidth="10"
          fill="none"
          strokeLinecap="round"
        />
        <path
          d="M 150 210 Q 250 220 380 280 T 520 390"
          stroke="#fcd34d"
          strokeWidth="3"
          strokeDasharray="8 6"
          fill="none"
        />

        {/* Corniche Ouest */}
        <path
          d="M 130 240 C 180 290, 250 350, 320 420"
          stroke="#ffffff"
          strokeWidth="8"
          fill="none"
        />

        {/* Autoroute de l'Avenir (A1) */}
        <path
          d="M 320 420 Q 450 380 620 320 T 790 280"
          stroke="#ffffff"
          strokeWidth="12"
          fill="none"
        />
        <path
          d="M 320 420 Q 450 380 620 320 T 790 280"
          stroke="#94a3b8"
          strokeWidth="2"
          fill="none"
        />

        {/* Secondary city grid lines */}
        <line x1="200" y1="180" x2="350" y2="340" stroke="#ffffff" strokeWidth="5" />
        <line x1="280" y1="160" x2="220" y2="320" stroke="#ffffff" strokeWidth="4" />
        <line x1="340" y1="260" x2="480" y2="240" stroke="#ffffff" strokeWidth="5" />
        <line x1="420" y1="360" x2="520" y2="260" stroke="#ffffff" strokeWidth="4" />

        {/* District Labels */}
        <text x="145" y="195" fill="#475569" fontSize="13" fontWeight="bold">Almadies</text>
        <text x="240" y="170" fill="#64748b" fontSize="11" fontWeight="600">Yoff Plage</text>
        <text x="210" y="270" fill="#64748b" fontSize="12" fontWeight="600">Ouakam / Mamelles</text>
        <text x="290" y="320" fill="#1e293b" fontSize="13" fontWeight="bold">Sacré-Cœur / VDN</text>
        <text x="320" y="440" fill="#0f172a" fontSize="14" fontWeight="bold">Dakar Plateau</text>
        <text x="470" y="320" fill="#64748b" fontSize="11" fontWeight="600">Maristes / Hann</text>
        <text x="630" y="300" fill="#64748b" fontSize="11" fontWeight="600">Pikine / Guédiawaye</text>
        <text x="730" y="260" fill="#0284c7" fontSize="11" fontWeight="bold">Vers AIBD ✈</text>

        {/* Active Route Path if Destination chosen */}
        {destPos && (
          <>
            <path
              d={getCurvePath(pickupPos, destPos)}
              stroke="#000000"
              strokeWidth="7"
              strokeLinecap="round"
              fill="none"
              opacity="0.3"
            />
            <path
              d={getCurvePath(pickupPos, destPos)}
              stroke="#F5B800"
              strokeWidth="5"
              strokeLinecap="round"
              fill="none"
            />
          </>
        )}

        {/* Nearby Drivers (taxis moving or idling) */}
        {drivers.map((drv) => {
          const dx = toSvgX(drv.location.lng);
          const dy = toSvgY(drv.location.lat);
          const isSelected = selectedDriver?.id === drv.id;

          return (
            <g
              key={drv.id}
              transform={`translate(${dx}, ${dy})`}
              className="cursor-pointer transition-transform duration-500 hover:scale-125"
            >
              {/* Taxi vehicle badge */}
              <circle
                r={isSelected ? 16 : 13}
                fill={drv.isOnline ? (isSelected ? '#F5B800' : '#111827') : '#94a3b8'}
                stroke="#ffffff"
                strokeWidth="2.5"
                filter="url(#shadow)"
              />
              <path
                d="M -5 -3 L 5 -3 L 6 3 L -6 3 Z"
                fill={isSelected ? '#111827' : '#F5B800'}
              />
              <circle cx="-3" cy="4" r="1.5" fill="#ffffff" />
              <circle cx="3" cy="4" r="1.5" fill="#ffffff" />

              {/* Status pulse if online */}
              {drv.isOnline && (
                <circle
                  r={isSelected ? 22 : 18}
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="1.5"
                  opacity="0.6"
                  className="animate-ping"
                />
              )}
            </g>
          );
        })}

        {/* Car on Route during ongoing ride */}
        {carPos && (
          <g transform={`translate(${carPos.x}, ${carPos.y})`} filter="url(#shadow)">
            <circle r="18" fill="#111827" stroke="#F5B800" strokeWidth="3" />
            <path d="M -7 -4 L 7 -4 L 8 4 L -8 4 Z" fill="#F5B800" />
            <circle cx="-4" cy="5" r="2" fill="#ffffff" />
            <circle cx="4" cy="5" r="2" fill="#ffffff" />
          </g>
        )}

        {/* Pickup Pin */}
        {pickupPos && (
          <g transform={`translate(${pickupPos.x}, ${pickupPos.y})`} filter="url(#shadow)">
            <circle r="20" fill="#F5B800" opacity="0.3" className="animate-pulse" />
            <circle r="9" fill="#F5B800" stroke="#111827" strokeWidth="2.5" />
            <circle r="3.5" fill="#111827" />
            {pickup && (
              <rect
                x="-50"
                y="-36"
                width="100"
                height="22"
                rx="6"
                fill="#111827"
                stroke="#F5B800"
                strokeWidth="1.5"
              />
            )}
            {pickup && (
              <text
                x="0"
                y="-22"
                fill="#ffffff"
                fontSize="9"
                fontWeight="700"
                textAnchor="middle"
              >
                Prise en charge
              </text>
            )}
          </g>
        )}

        {/* Destination Pin */}
        {destPos && (
          <g transform={`translate(${destPos.x}, ${destPos.y})`} filter="url(#shadow)">
            <path
              d="M 0 0 L -8 -22 A 8 8 0 1 1 8 -22 Z"
              fill="#111827"
              stroke="#ffffff"
              strokeWidth="2"
            />
            <circle cx="0" cy="-22" r="3.5" fill="#F5B800" />
            {destination && (
              <rect
                x="-45"
                y="-54"
                width="90"
                height="20"
                rx="5"
                fill="#ffffff"
                stroke="#111827"
                strokeWidth="1"
              />
            )}
            {destination && (
              <text
                x="0"
                y="-40"
                fill="#111827"
                fontSize="9"
                fontWeight="700"
                textAnchor="middle"
              >
                Destination
              </text>
            )}
          </g>
        )}
      </svg>

      {/* Floating Map Controls */}
      <div className="absolute right-3 top-3 flex flex-col gap-2 z-10">
        <button
          onClick={() => setZoom((z) => Math.min(z + 0.25, 2.5))}
          className="p-2.5 bg-white text-neutral-800 rounded-xl shadow-md border border-neutral-200 hover:bg-neutral-50 transition active:scale-95"
          title="Zoomer"
        >
          <Plus size={18} />
        </button>
        <button
          onClick={() => setZoom((z) => Math.max(z - 0.25, 0.75))}
          className="p-2.5 bg-white text-neutral-800 rounded-xl shadow-md border border-neutral-200 hover:bg-neutral-50 transition active:scale-95"
          title="Dézoomer"
        >
          <Minus size={18} />
        </button>
        <button
          onClick={resetView}
          className="p-2.5 bg-white text-neutral-800 rounded-xl shadow-md border border-neutral-200 hover:bg-neutral-50 transition active:scale-95"
          title="Recentrer Dakar"
        >
          <Compass size={18} />
        </button>
      </div>

      {/* City Badge */}
      <div className="absolute left-3 top-3 bg-white/90 backdrop-blur-sm px-3 py-1.5 rounded-full shadow-sm border border-neutral-200 flex items-center gap-1.5 text-xs font-semibold text-neutral-800 pointer-events-none">
        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
        <span>Dakar, Sénégal</span>
        <span className="text-neutral-400">|</span>
        <Bike size={13} className="text-amber-500" />
        <span className="text-neutral-600">{drivers.filter(d => d.isOnline).length} motards en ligne</span>
      </div>
    </div>
  );
};
