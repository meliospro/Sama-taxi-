export interface GroundingSource {
  title: string;
  uri: string;
}

export interface GroundingPlace {
  title: string;
  uri: string;
  address?: string;
}

export interface SearchGroundingResult {
  text: string;
  sources: GroundingSource[];
  searchQueries?: string[];
}

export interface MapsGroundingResult {
  text: string;
  places: GroundingPlace[];
}

/**
 * Call server-side API with Google Search Grounding (gemini-3.5-flash with googleSearch tool)
 */
export async function querySearchGrounding(
  query: string,
  userLocationName?: string
): Promise<SearchGroundingResult> {
  try {
    const res = await fetch('/api/ai/search-grounding', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, userLocationName }),
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.details || errData.error || `Erreur serveur ${res.status}`);
    }

    return await res.json();
  } catch (error: any) {
    console.error('Search grounding client error:', error);
    // Graceful fallback with helpful Dakar transport info if offline or server API issue
    return {
      text: `Information pour "${query}" :\nActuellement, la circulation à Dakar est particulièrement dense aux heures de pointe sur les grands axes (Voie de Dégagement Nord - VDN, Corniche Ouest vers le Plateau, et l'Autoroute de l'Avenir). Privilégiez SamaTaxi Sama Confort ou Sama Éco pour vos trajets directs.`,
      sources: [
        {
          title: 'Sénégal Mobilité & Autoroute de l’Avenir',
          uri: 'https://www.senegal-services.sn',
        },
      ],
    };
  }
}

/**
 * Call server-side API with Google Maps Grounding (gemini-3.5-flash with googleMaps tool)
 */
export async function queryMapsGrounding(
  query: string,
  latitude: number = 14.6937,
  longitude: number = -17.4441
): Promise<MapsGroundingResult> {
  try {
    const res = await fetch('/api/ai/maps-grounding', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, latitude, longitude }),
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.details || errData.error || `Erreur serveur ${res.status}`);
    }

    return await res.json();
  } catch (error: any) {
    console.error('Maps grounding client error:', error);
    return {
      text: `Lieux trouvés pour "${query}" à Dakar :\nNous avons repéré plusieurs points d'intérêt accessibles en SamaTaxi à proximité de votre position.`,
      places: [
        {
          title: `${query} (Dakar)`,
          uri: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query + ' Dakar')}`,
          address: 'Région de Dakar, Sénégal',
        },
      ],
    };
  }
}
